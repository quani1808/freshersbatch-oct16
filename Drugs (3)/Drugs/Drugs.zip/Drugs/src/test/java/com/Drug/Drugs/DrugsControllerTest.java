/*
 * package com.Drug.Drugs;
 * 
 * import static org.mockito.Mockito.doReturn; import static
 * org.mockito.ArgumentMatchers.any; import static
 * org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
 * import static
 * org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
 * 
 * //import static org.junit.jupiter.api.Assertions.*;
 * 
 * import org.junit.jupiter.api.Test; //import
 * org.junit.jupiter.api.DisplayName; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
 * import org.springframework.boot.test.context.SpringBootTest; import
 * org.springframework.boot.test.mock.mockito.MockBean; import
 * org.springframework.http.MediaType; import
 * org.springframework.test.web.servlet.MockMvc;
 * 
 * import com.Drug.Drugs.models.Drugs; import
 * com.Drug.Drugs.service.DrugsService; import
 * com.fasterxml.jackson.databind.ObjectMapper;
 * 
 * import java.time.LocalDate; //import java.util.Date; import
 * java.util.Optional; import com.google.common.collect.Lists;
 * 
 * import static
 * org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*; import
 * static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
 * 
 * import static org.hamcrest.Matchers.*;
 * 
 * @SpringBootTest
 * 
 * @AutoConfigureMockMvc class DrugsControllerTest{
 * 
 * 
 * @MockBean private DrugsService service;
 * 
 * @Autowired private MockMvc mockMvc;
 * 
 * @Test // @DisplayName("GET /Drugs success") public void testGetDetails()
 * throws Exception { Drugs drugs = new Drugs(2,"abcs", 15.0, 5, "Bia",
 * "JK",LocalDate.of(2022, 02, 01)); Drugs drugs1 = new Drugs(13,"abcs2", 15.0,
 * 5, "Bias", "JK", LocalDate.of(2022, 12, 1));
 * doReturn(Lists.newArrayList(drugs, drugs1)).when(service).getAllDetails();
 * mockMvc.perform(
 * get("/drugs/list")).andExpect(status().isOk()).andExpect(content().
 * contentType(MediaType.APPLICATION_JSON)) .andExpect(jsonPath("$",
 * hasSize(2))); }
 * 
 * @Test public void testSaveDrugsDetails() throws Exception { Drugs drugs1 =
 * new Drugs(13,"abcs2", 15.0, 5, "Bias", "JK", LocalDate.of(2023, 8, 21));
 * doReturn(drugs1).when(service).saveDrugsDetails(any());
 * 
 * mockMvc.perform(post("/drugs/") .contentType(MediaType.APPLICATION_JSON)
 * .content(asJsonString(drugs1))).andExpect(status().isOk()).andExpect(content(
 * ).contentType(MediaType.APPLICATION_JSON)) .andExpect(jsonPath("$.drugsId",
 * is(13))); }
 * 
 * 
 * @Test public void testGetDrugsById() throws Exception{
 * 
 * Drugs drugs1 = new Drugs(1,"abcs2", 15.0, 5, "Bias","JK", LocalDate.of(2023,
 * 01, 18)); doReturn(Optional.of(drugs1)).when(service).getDrugsByID(13);
 * 
 * mockMvc.perform(get("/drugs/{id}",13)).andExpect(status().isOk()).andExpect(
 * content().contentType(MediaType.APPLICATION_JSON))
 * .andExpect(jsonPath("$.drugsId", is(1))); }
 * 
 * 
 * @Test public void testUpdateDrugsDetails() throws Exception { Drugs drugs1 =
 * new Drugs(2,"abcs2", 15.0, 5, "Bias", "JK", LocalDate.of(2023, 03, 30) );
 * Drugs updated = new Drugs(3,"abcs2", 16.0, 5, "Bias","JK", LocalDate.of(2023,
 * 12, 06)); doReturn(Optional.of(drugs1)).when(service).getDrugsByID(13);
 * doReturn(updated).when(service).updateDrugsDetails(12, drugs1);
 * 
 * mockMvc.perform(put("/drugs/{id}",13)
 * .contentType(MediaType.APPLICATION_JSON)
 * .content(asJsonString(updated))).andExpect(status().isOk()).andExpect(content
 * ().contentType(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.drugsId",
 * is(1))).andExpect(jsonPath("$.drugsCost", is(16.0))); } static String
 * asJsonString(final Object obj) { try { return new
 * ObjectMapper().writeValueAsString(obj); } catch (Exception e) { throw new
 * RuntimeException(e); } }
 * 
 * 
 * 
 * }
 */