package com.Drug.Drugs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugsApplicationTests {

	@Test
	void contextLoads() {
	}

}
